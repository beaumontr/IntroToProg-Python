# -------------------------------------------------#
# Title: Pickling Example
# Dev:   RBeaumont
# Date:  December 2, 2018
# ChangeLog: (Who, When, What)
#   RBeaumont, 12/02/2018, Wrote script
# -------------------------------------------------#

#In this script, we document an example for the use of pickling

import pickle

dicRow1 = {"Action": "Clean Sheets", "Priority": "low"}
dicRow2 = {"Action": "Empty Dishwasher", "Priority": "high"}
dicRow3 = {"Action": "Vacuum Floor", "Priority": "high"}

lstDicRows = [dicRow1, dicRow2, dicRow3]

objFile = open("C:\\_PythonClass\\Assignment07\Pickling_Example.dat", "ab")

pickle.dump(lstDicRows, objFile)

objFile.close()

objFile = open("C:\\_PythonClass\\Assignment07\Pickling_Example.dat", "rb")
print(pickle.load(objFile))
objFile.close()
