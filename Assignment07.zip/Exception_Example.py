# -------------------------------------------------#
# Title: Exception Handling Example
# Dev:   RBeaumont
# Date:  December 2, 2018
# ChangeLog: (Who, When, What)
#   RBeaumont, 12/02/2018, Wrote script
# -------------------------------------------------#

#In this script, we add exception handling to user input selection

try:
    #Present the user with a set of options
    print("""
                Menu of Options
                1) Show current data
                2) Add a new item.
                3) Remove an existing item.
                4) Save Data to File
                5) Exit Program
                """)

    #Store the user's choice as an integer
    intChoice = int(input("Which option would you like to perform? [1 to 5] - "))

    #Raise an exception if there is an invalid numeric input
    if intChoice > 5 or intChoice < 1:
        raise Exception('Invalid Input. You must choose a selection between 1 and 5.')

#if the user didn't input a number, raise an error
except ValueError as e:
    print('-------------------------------------------------------------------')
    print("ERROR:")
    print("Invalid Input. Input must be a number (e.g. '1')")
    print('-------------------------------------------------------------------')

#identify any other exceptions
except Exception as e:
    print('-------------------------------------------------------------------')
    print("ERROR:")
    print(e)
    print('-------------------------------------------------------------------')


