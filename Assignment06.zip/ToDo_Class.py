# -------------------------------------------------#
# Title: To Do List with Class and Methods
# Dev:   RBeaumont
# Date:  November 25, 2018
# ChangeLog: (Who, When, What)
#   RBeaumont, 11/25/2018, Wrote script
# -------------------------------------------------#

#define the primary class
class ToDo(object):
    """This class contains methods for supporting To Do list creation and editing"""

    #define the first method
    def LoadData(objFileName):
        """This function loads to do list data from a text file into a Python dictionary (which is returned)"""
        lstMaster = []
        objTextFile = open(objFileName,"r")
        for line in objTextFile:
            listRow = line.split(",")
            dicRow = {"Action": listRow[0], "Priority": listRow[1]}
            lstMaster.append(dicRow)
        objTextFile.close()
        return lstMaster

    #define the second method
    def ChoiceMenu(self):
        """This function displays a list of options to the user and returns the selected option"""
        print("""
            Menu of Options
            1) Show current data
            2) Add a new item.
            3) Remove an existing item.
            4) Save Data to File
            5) Exit Program
            """)
        strChoice = str(input("Which option would you like to perform? [1 to 5] - "))
        print()  # adding a new line
        return strChoice

    #define the third method
    def CurrentList(lstMaster):
        """This function shows the current items in the to do list"""
        print("---------------------------------------")
        print("The current items in the list are: ")
        for line in lstMaster:
            lstTemp = []
            for myKey, myValue in line.items():
                strTemp = myValue
                lstTemp.append(strTemp)
            strDisplay = lstTemp[0] + "," + lstTemp[1]
            print(strDisplay.strip())
        print("---------------------------------------")

    #define the fourth method
    def AddItem(lstMaster):
        """This function adds a new item to the list"""
        strAction = input("Enter Action: ")
        strPriority = input("Enter Priority (high/low): ")
        dicRowNew = {"Action": strAction, "Priority": strPriority.lower()}
        lstMaster.append(dicRowNew)
        print("Action Added.")
        return lstMaster

    #define the fifth method
    def RemoveItem(lstMaster):
        """This function removes an item from the list"""
        strResponse = input("Which ACTION would you like to remove? - ")
        count = 0
        for dic in lstMaster:
            for key, value in dic.items():
                if value == strResponse:
                    del lstMaster[count]
            count = count + 1
        print("Action removed.")
        return lstMaster

    #define the sixth method
    def SaveList(lstMaster, objFileName):
        """This function saves the to do list to a file"""
        objTextFile = open(objFileName, "w")
        for line in lstMaster:
            lstTemp = []
            for myKey, myValue in line.items():
                strTemp = myValue
                lstTemp.append(strTemp)
            strWrite = "\n" + lstTemp[0] + "," + lstTemp[1]
            objTextFile.write(strWrite.strip() + "\n")
        objTextFile.close()
        print("File updated.")


#Input/Output
objFileName = "C:\_PythonClass\Assignment06\Todo.txt" #name of file where to-do list is stored
lstMaster = ToDo.LoadData(objFileName) #load current data in the file into a list

while(True):

    strChoice = ToDo.ChoiceMenu(ToDo)

    if (strChoice.strip() == '1'):  #1 = "show current data"
        ToDo.CurrentList(lstMaster)

    elif (strChoice.strip() == '2'): #2 = "add a new item"
        lstMaster = ToDo.AddItem(lstMaster)

    elif (strChoice.strip() == '3'): #3 = "remove an existing item"
        lstMaster = ToDo.RemoveItem(lstMaster)

    elif (strChoice.strip() == '4'): #4 = "save data to a file"
        ToDo.SaveList(lstMaster, objFileName)

    elif (strChoice.strip() == '5'): #5 = "exit program"
        break



