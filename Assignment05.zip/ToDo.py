# -------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   RBeaumont
# Date:  November 18, 2018
# ChangeLog: (Who, When, What)
#   RBeaumont, 11/18/2018, Added code to complete assignment 5
# -------------------------------------------------#

#Preliminary data and "global" variables
objFileName = "C:\_PythonClass\Assignment05\Todo.txt"
strData = ""
dicRow = {}
lstTable = []
listRow = []
lstMaster = []

# Step 1 - Load data from a file
objTextFile = open(objFileName, "r")
for line in objTextFile:
    listRow = line.split(",")
    dicRow = {"Action":listRow[0],"Priority":listRow[1]}
    lstMaster.append(dicRow)
objTextFile.close()


# Step 2 - Display a menu of choices to the user
while (True):
    print("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
    print()  # adding a new line

    # Step 3 -Show the current items in the table
    if (strChoice.strip() == '1'):
        print("---------------------------------------")
        print("The current items in the list are: ")
        for line in lstMaster:
            lstTemp = []
            for myKey,myValue in line.items():
                strTemp = myValue
                lstTemp.append(strTemp)
            strDisplay = lstTemp[0] +  "," + lstTemp[1]
            print(strDisplay.strip())
        print("---------------------------------------")

    # Step 4 - Add a new item to the list/Table
    elif (strChoice.strip() == '2'):
        strAction = input("Enter Action: ")
        strPriority = input("Enter Priority (high/low): ")
        dicRowNew = {"Action": strAction, "Priority": strPriority.lower()}
        lstMaster.append(dicRowNew)
        print("Action Added.")

    # Step 5 - Remove an item from the list/Table
    elif (strChoice == '3'):
        strResponse = input("Which ACTION would you like to remove? - ")
        count = 0
        for dic in lstMaster:
            for key, value in dic.items():
                if value == strResponse:
                    del lstMaster[count]
            count = count + 1
        print("Action removed.")


    # Step 6 - Save tasks to the ToDo.txt file
    elif (strChoice == '4'):
        objTextFile = open(objFileName, "w")
        for line in lstMaster:
            lstTemp = []
            for myKey,myValue in line.items():
                strTemp = myValue
                lstTemp.append(strTemp)
            strWrite = "\n" + lstTemp[0] +  "," + lstTemp[1]
            objTextFile.write(strWrite.strip() + "\n")
        objTextFile.close()
        print("File updated.")

    #Step 7 - exit the program
    elif (strChoice == '5'):
        break  # and Exit the program

